﻿using DG.Tweening;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.VR;
using UnityEngine.SceneManagement;
using System.Collections;
using System.Collections.Generic;

public class Calibrator : MonoBehaviour
{
    public Camera myCamera;
    public GameObject forward;
    public AudioClip coin;

    public UICalibrator progressLeft;
    public UICalibrator progressRight;

    public bool canCheckSides;

    [Range(-1f, 1f)]
    public float lookDirectionNormal;
    public float deltaAngle;
    public float timeToShow;
    public float timeToStart;

    // Update is called once per frame
    void Update()
    {
        if (canCheckSides)
            CheckSides();

        if (Input.GetKeyDown(KeyCode.Return))
            Invoke("CanCheck", timeToShow);
    }

    public void CanCheck()
    {
        InputTracking.Recenter();
        canCheckSides = true;
    }

    public void CheckSides()
    {
        Vector3 localRotation = myCamera.transform.localRotation.eulerAngles;

        if (localRotation.x < 40 || localRotation.x > 320f)
        {
            float angle = Vector3.Angle(forward.transform.forward, myCamera.transform.forward);
            float remap = ExtensionMethods.Remap(angle, 0f, deltaAngle, 0f, 1f);

            if (localRotation.y >= 0f && localRotation.y <= 180f)
                lookDirectionNormal = Mathf.Clamp01(remap);

            else if (localRotation.y <= 360f || localRotation.y > 180f)
                lookDirectionNormal = -Mathf.Clamp01(remap);

            if (lookDirectionNormal >= 0f && !progressRight.sideCompleted)
            {
                progressRight.progressThumb.value = Mathf.Abs(lookDirectionNormal);
                progressRight.progressBar.fillAmount = Mathf.Abs(lookDirectionNormal);

                if (lookDirectionNormal == 1f)
                {
                    progressRight.sideCompleted = true;
                    progressRight.animation.Play();
                    AudioSource.PlayClipAtPoint(coin, transform.position);
                    progressRight.tweenAnimation.DOPlay();

                    if (progressRight.sideCompleted && progressLeft.sideCompleted)
                        Invoke("StartTrack", timeToStart);
                }
            }

            else if (lookDirectionNormal <= 0f && !progressLeft.sideCompleted)
            {
                progressLeft.progressThumb.value = Mathf.Abs(lookDirectionNormal);
                progressLeft.progressBar.fillAmount = Mathf.Abs(lookDirectionNormal);

                if (lookDirectionNormal == -1f)
                {
                    progressLeft.sideCompleted = true;
                    progressLeft.animation.Play();
                    AudioSource.PlayClipAtPoint(coin, transform.position);
                    progressLeft.tweenAnimation.DOPlay();

                    if (progressLeft.sideCompleted && progressRight.sideCompleted)
                        Invoke("StartTrack", timeToStart);
                }
            }
        }
    }

    public void StartTrack()
    {
        SceneManager.LoadScene("Scenes/Main/Maps");
    }
}
