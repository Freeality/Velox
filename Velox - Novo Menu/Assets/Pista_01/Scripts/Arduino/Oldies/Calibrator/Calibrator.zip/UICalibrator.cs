﻿using DG.Tweening;
using UnityEngine;
using UnityEngine.UI;
using System.Collections;

[System.Serializable]
public class UICalibrator
{
    public Scrollbar progressThumb;
    public Image progressBar;
    public Animation animation;
    public DOTweenAnimation tweenAnimation;
    [HideInInspector]
    public bool sideCompleted = false;
}
